# RegMagic-std
Standard version of Registration Magic WP plugin.
