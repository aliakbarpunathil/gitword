<?php
require_once plugin_dir_path(__FILE__).'interface_rm_exporter.php';

/**
 * Description of class_rm_http_get
 *
 * @author CMSHelplive
 */
class RM_Export_GET implements RM_Exporter
{
    public function prepare_data()
    {
        ;
    }
    
    public function send_data(array $data)
    {
        ;
    }
}
